<?PHP
?>

<div class="modal fade" id="modal" role="dialog" data-backdrop="static" data-keyboard="false">
    
    <div class="col-xs-1 col-sm-2 col-md-2"></div>

    <div class="modal-dialog col-xs-10 col-sm-8 col-md-8">
        <div class="modal-content">
            <div id="titleModal" class="modal-header text-center">
                
            </div>
            <div class="modal-body">
                <div class="row">
                    <div id="bodyModal" class="col-md-12">
                        
                    </div>
                </div>
            </div>
            <div class="modal-footer text-center">
                <div id="footerModal" class="col-md-12 text-center">
                </div>
            </div>
        </div>
    </div>

    <div class="col-xs-1 col-sm-2 col-md-2"></div>

</div>