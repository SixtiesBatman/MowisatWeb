<?PHP
/*Versión Bamboostr*/
$version_bamboostr = "";
/*Fin Versión Bamboostr*/
/*Dirección Principal*/
$direccion_principal_config = "mowisatinvest.mx";
//$direccion_principal_config = "localhost/bamboostr";
//$direccion_principal_config = "localhost:8000";
//$direccion_principal_config = "bam.boogapp.com";
//$direccion_principal_config = "bamboostr.com";
//$direccion_principal_config = "betatest.bamboostr.com";
/*Fin Dirección Principal*/
/*Base de datos*/
$db_server = "localhost";
$db_user = "root";
$db_passwd = "";
//$db_user = "fguyer4398re";
//$db_passwd = "eruthr3847r9weiug";
$db_name = "mowisatweb";
/*Fin Base de datos*/

?>