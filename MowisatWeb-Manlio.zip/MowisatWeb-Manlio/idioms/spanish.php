<?PHP

//index.php

$txt["propuestaDeValor"] = "Conectar cualquier cosa <br/>en cualquier lugar.";
$txt["descripcionPropuestaDeValor"] = "Traducción de la descripción";

?>