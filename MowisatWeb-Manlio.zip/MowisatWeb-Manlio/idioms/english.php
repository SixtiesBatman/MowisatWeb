<?PHP

//index.php

$txt["propuestaDeValor"] = "Connecting Anything, <br/>Anywhere.";
$txt["descripcionPropuestaDeValor"] = "Mowisat Corporation commercializes Satellite<br />
Broadband in Latin America for versatile use.<br />
Powered by cutting edge connectivity solutions<br />
for business processes optimization.";
?>