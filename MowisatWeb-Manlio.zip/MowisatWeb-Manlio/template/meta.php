<?PHP
?>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />        
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="styles/style.css" rel="stylesheet" type="text/css">
<link rel="shortcut icon" href="images/favicon_mowisat.png">
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="styles/bootstrap.css">

<!-- jQuery library -->
<script src="js/jquery.js"></script>

<!-- Latest compiled JavaScript -->
<script src="js/bootstrap.js"></script>


<script src="js/toastr.js"></script>
<link rel="stylesheet" href="styles/toastr.css">

<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">

<link rel="stylesheet" href="styles/font-awesome.css">
<link rel="stylesheet" href="styles/fonts-apply.css">

<style>
.container-fluid{
    padding-right: 0 !important;
    padding-left: 0 !important;
}
.row {
    margin-right: 0 !important;
    margin-left: 0 !important;
}
</style>